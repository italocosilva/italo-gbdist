from setuptools import setup

setup(name='italo_gbdist',
      version='0.2',
      description='Gaussian and Binomial distributions',
      packages=['italo_gbdist'],
      author = 'Italo Castilho',
      zip_safe=False)
